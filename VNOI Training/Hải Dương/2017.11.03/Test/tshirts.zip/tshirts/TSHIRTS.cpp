/*-----DP: bottom-up iterative-----*/
#include<bits/stdc++.h>
//#define DEBUG
//#ifdef DEBUG
//code to debug
//#endif
//#undef DEBUG
using namespace std;

const int mod=1e9+7,maxn=105;
#define F(i,p,n) for(int i=p;i<n;i++)
#define I(i,p,q) for(int i=p;i>=q;i--)
#define Ss(x) scanf("%s",x)
//#define S(x) scanf("%d",&x)
#define getcx getchar
inline void S(int& n)
{
    n=0; int ch = getcx(); int sign = 1;
    while(ch < '0' || ch > '9') { if(ch == '-') sign=-1; ch = getcx(); }
    while(ch >= '0' && ch <= '9') { n = (n << 3) + (n << 1) + ch - '0', ch = getcx(); }
    n = n * sign;
}
#define Ps(x) printf("%d  ",x)
#define P(x) printf("%d\n",x)
typedef long long int LL;
#define Bug(x) cout << #x << "=" << x << endl
#define pii pair<int,int>
#define chk(x,n) (x[n>>5]&(1<<(n&31))) //unsigned int
#define set(x,n) (x[n>>5]|=(1<<(n&31)))//32 bit

int memo[1<<10][maxn],info[15][maxn];

int main()
{
    freopen("test20\\tshirts.inp","r",stdin);
    freopen("test20\\tshirts.out","w",stdout);
    int t;

    S(t);

    while(t--)
    {
        int n;
        S(n);

        char ch;

        F(i,1,n+1)
        {
            int num=0;
            while((ch=getchar())!='\n')
            {
                if(ch==' ')
                {
                    info[i][num]=1;
                    num=0;
                    continue;
                }
                num=10*num+(ch-'0');

            }
            info[i][num]=1;
        }

        memo[0][0]=1;

        F(i,0,(1<<n))
        {
            F(j,1,101)
            {
                memo[i][j]+=memo[i][j-1];
                if(memo[i][j]>=mod)
                    memo[i][j]-=mod;
            }
            F(j,1,n+1)
            {
                int mask=(1<<(j-1));
                if(!(i&mask))
                {
                    mask|=i;
                    F(k,1,101)
                    {
                        if(info[j][k])
                        {
                            memo[mask][k]+=memo[i][k-1];
                            if(memo[mask][k]>=mod)
                                memo[mask][k]-=mod;
                        }
                    }
                }
            }
        }

        P(memo[(1<<n)-1][100]);

        memset(memo,0,sizeof(memo));
        memset(info,0,sizeof(info));
    }

   return 0;
}
