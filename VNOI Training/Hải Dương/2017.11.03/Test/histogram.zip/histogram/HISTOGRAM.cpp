#include <bits/stdc++.h>
#define maxn 16
#define maxx 1000000

using namespace std;
typedef long long lint;

int n, h[maxn];
int f[maxx][maxn], nho[maxx][maxn];
lint g[maxx][maxn];

void calc(int x,int k) {
    if (nho[x][k]) return;
    nho[x][k]=1;
    f[x][k]=0, g[x][k]=0;
    int y=x ^ (1<<(k-1));
    if (y==0) {
        f[x][k]=2*h[k]+1;
        g[x][k]=1;
        return;
    }
    for(int l=1;l<=n;l++) if ((x & (1<<(l-1)))!=0 && (l!=k)) {
        calc(y,l);
        int cv=f[y][l]-h[l]+abs(h[k]-h[l])+1+h[k];
        if (cv>f[x][k]) f[x][k]=cv, g[x][k]=g[y][l]; else
        if (cv==f[x][k]) g[x][k]+=g[y][l];
    }
}


void solve() {
    for(int x=0;x<(1<<n);x++)
        for(int i=1;i<=n;i++) nho[x][i]=0;
    nho[0][0]=1; f[0][0]=0; g[0][0]=1;
    for(int k=1;k<=n;k++) calc((1<<n)-1,k);
    int ans=0;
    lint cnt=0;
    for(int k=1;k<=n;k++) if (ans<f[(1<<n)-1][k]) ans=f[(1<<n)-1][k], cnt=g[(1<<n)-1][k];
    else if (ans==f[(1<<n)-1][k]) cnt+=g[(1<<n)-1][k];
    cout << ans+n << " " << cnt << "\n";
}

int main() {
    freopen("histogram.inp","r",stdin);
    freopen("histogram.out","w",stdout);
    ios::sync_with_stdio(false);
    while (1) {
        cin >> n;
        if (n==0) break;
        for(int i=1;i<=n;i++) cin >> h[i];
        solve();
    }
}
