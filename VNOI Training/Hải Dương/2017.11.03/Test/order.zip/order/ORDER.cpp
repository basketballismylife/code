#include <bits/stdc++.h>
#define maxn 17
#define INF 2000000000

using namespace std;

int n, a[maxn][maxn];
int f[1<<17],nho[1<<17];

int calc(int x) {
    if (nho[x]) return f[x];
    if (x==0) return 0;
    nho[x]=1;
    for(int i=0;i<n;i++) if ((x & (1<<i))) {
        int y=x^(1<<i);
        int t=a[i+1][i+1];
        for(int j=0;j<n;j++) if ((y & (1<<j))) t+=a[i+1][j+1];
        t+=calc(y);
        if (t<f[x]) f[x]=t;
    }
    return f[x];
}

int main() {
    freopen("order.inp","r",stdin);
    freopen("order.out","w",stdout);
    ios::sync_with_stdio(false);
    cin >> n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) cin >> a[i][j];
    for(int x=0;x<(1<<n);x++) f[x]=INF, nho[x]=0;
    cout << calc((1<<n)-1);
}
